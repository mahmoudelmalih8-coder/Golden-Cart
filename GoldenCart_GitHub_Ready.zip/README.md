# GoldenCart — Android Studio

هذه نسخة Android Studio مصححة لتطبيق GoldenCart. تم إصلاح مشكلة مسارات ملفات HTML داخل WebView: النسخة السابقة كانت تستخدم مسارات `/style.css` و`/app.js`، وهي لا تعمل داخل `file:///android_asset/`.

## التشغيل
1. فك الضغط.
2. افتح المجلد `GoldenCart_AndroidStudio` من Android Studio.
3. انتظر Gradle Sync.
4. Build > Build APK(s).

## وضع التشغيل الحالي
التطبيق يعمل بواجهة المتجر محليًا حتى بدون سيرفر، ويحتوي على بيانات تجريبية وتخزين محلي للطلبات والمنتجات. رمز الإدارة المحلي التجريبي: `1234`. **غيّره قبل أي استخدام فعلي.**

## التشغيل الأونلاين
قبل النشر التجاري، يجب ربط `API_BASE` في `app/src/main/assets/app.js` بعنوان HTTPS للسيرفر، ثم وضع المصادقة الحقيقية على الخادم. مفاتيح Alibaba/AliExpress لا توضع داخل التطبيق.
