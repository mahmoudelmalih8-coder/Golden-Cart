# GoldenCart — رفع المشروع من الموبايل

1. افتح مستودع GitHub باسم Golden-Cart.
2. اختر Add file ثم Upload files.
3. ارفع **محتويات هذا المجلد** إلى جذر المستودع، وليس المجلد الأب نفسه.
4. اضغط Commit changes.
5. بعد الرفع افتح تبويب Actions واختر Build GoldenCart APK.
6. اضغط Run workflow إذا لم يبدأ البناء تلقائيًا.
7. بعد نجاح البناء افتح العملية الناجحة ثم Artifacts ثم GoldenCart-debug-apk لتحميل APK.

ملاحظة: هذه النسخة تبني APK تجريبيًا (Debug). التكامل الحقيقي مع Alibaba/AliExpress والسيرفر والدفع يحتاج إعدادًا منفصلًا وآمنًا.
